﻿using System;

namespace TargetLibrary
{
    public class InsuranceRiskInformation
    {
        public Gender Gender { get; set; }
        public AgeGroup AgeGroup { get; set; }
        public Province Province { get; set; }
    }
}
